-----------------------------------------------------------------------
Paper Cut - Freeware Font - Created by Eoin [ smulvi@iol.ie ]
December 21st 2000
-----------------------------------------------------------------------

THIS FONT NOT BE DISTRIBUTED WITHOUT THIS README FILE AND THE PAPERCUT.GIF IMAGE

Paper Cut is a free ware font, so feel free to use it on your websites or wherever you want,

All I ask is that if you use it in a site that you could PLEASE send me the link so I can see how you used it - i'd like to know where mystuff is goin ;)

This is my first font - if you think its good or have any comments / suggestions I'd REALLY appreciate them - send them to smulvi@iol.ie

I also included a picture of how the font looks - papercut.gif

Thanks
- Eoin